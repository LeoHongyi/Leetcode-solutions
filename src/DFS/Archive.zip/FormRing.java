package DFS;

/**
 * Given an array of strings, find if all the strings can be chained to form a circle. Two string s1 and s2 can be chained, iff the last letter of s1 is identical to the first letter of s2.
 *  For example,
 * “abc” and “cd” can be chained,
 * “abc” and “dz” can not be chained.
 *  Example Input:
 * arr[] = {"aaa", "bbb", "baa", "aab"};
 * Output: True,
 * The given input strings can be chained to form a circle. The strings can be chained as "aaa", "aab", "bbb" and "baa"
 * Method: DFS swap swap combinations
 * time : O(n!), space O(array.length())
 * **/
public class FormRing {
	public boolean formRing(String[] input) {
		if (input == null || input.length == 0) {
			return false;
		}
		boolean[] result = new boolean[1];
		formRingDFS(input, 0, "", result);
		return result[0];
	}
	private void formRingDFS(String[] input, int index, String cur, boolean[] result) {
		// base case
		if (index == input.length || result[0]) {
			// check word can form a ring.
			if (cur.charAt(0) == cur.charAt(cur.length() - 1)) {
				result[0] = true;
			}
			return;
		}
		for (int i = index; i < input.length; i++) {
			swap(input, index, i);
			if (index == 0) {
				String temp = cur + input[i];
				formRingDFS(input, index + 1, temp, result);
			} else {
				if (cur.charAt(cur.length() - 1) == input[i].charAt(input[i].length() - 1)) {
					String temp = cur + input[i];
					formRingDFS(input, index + 1, temp, result);
				}
			}
			swap(input, index, i);
		}
	}
	private void swap(String[] input, int index, int i) {
		String temp = input[index];
		input[index] = input[i];
		input[i] = temp;
	}
}
