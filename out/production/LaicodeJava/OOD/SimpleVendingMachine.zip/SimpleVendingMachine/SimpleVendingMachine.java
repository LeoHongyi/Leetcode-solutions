package OOD.SimpleVendingMachine;

public class SimpleVendingMachine {
	public static void main(String[] args) {
		VendAutomator automator = new VendAutomator();
		automator.simulate();
	}
}